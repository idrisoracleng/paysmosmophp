<div>
    <form msg="Adding <?php echo $name ?> to cart..." action="<?php echo site_url('/buyer/addtocart') ?>" method="POST">
        <input type="<?php echo (isset($means) && $means == 'gift') ? 'hidden' : 'number' ?>" id="qty" name="qty" min="1" value="1" max="<?php echo $quantity ?>" placeholder="qty"/>
        <input type="hidden" id="pname" name="name" value="<?php echo $name ?>"/>
        <input type="hidden" id="owner_id" name="owner_id" value="<?php echo $owner_id ?>"/>
        <input type="hidden" id="id" name="id" value="<?php echo $id; ?>"/>
        <input type="hidden" id="product_id" name="product_id" value="<?php echo $product_id ?>"/>
        <input type="hidden" id="pprice" name="price" value="<?php echo $price; ?>"/>
		<input type="hidden" id="oto" name="oto" value="oto" />
		<input type="hidden" id="purchase_means" name="purchase_means" value="<?php echo (isset($means)) ? $means : 'money'; ?>" />

        <button type="submit" class="btn btn-warning"><i class="fa fa-shopping-cart"></i> Add To Cart</button>

    </form>
</div>
