<div class="col-sm-2 bg-dark">

    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
        <a class="nav-link <?php echo ($active == 'home') ? 'active' : ''; ?>" href="<?php echo site_url('buyer/home'); ?>" role="tab" aria-controls="v-pills-home" aria-selected="true">
            Home
        </a>
        <a class="nav-link <?php echo ($active == 'carts') ? 'active' : ''; ?>" href="<?php echo site_url('buyer/cart/my_cart'); ?>" role="tab" aria-controls="v-pills-carts" aria-selected="false">
            Carts
        </a>
        <a class="nav-link <?php echo ($active == 'orders') ? 'active' : ''; ?>" href="<?php echo site_url('buyer/orders/my_orders'); ?>" role="tab" aria-controls="v-pills-orders" aria-selected="false">
            Orders
        </a>
        <a class="nav-link <?php echo ($active == 'profile') ? 'active' : ''; ?>" href="<?php echo site_url('buyer/profile/view_profile'); ?>" role="tab" aria-controls="v-pills-profile" aria-selected="false">
            Profile
        </a>
        <a class="nav-link <?php echo ($active == 'settings') ? 'active' : ''; ?>" href="<?php echo site_url('buyer/profile/edit_profile'); ?>" role="tab" aria-controls="v-pills-settings" aria-selected="false">
            Settings
        </a>

        <a class="nav-link" href="<?php echo site_url('buyer/logout'); ?>" role="tab">
            Logout
        </a>
    </div>

</div>