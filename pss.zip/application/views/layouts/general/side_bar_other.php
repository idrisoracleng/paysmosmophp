<div class="card bg-gold">
    <h5 class="card-header">
        Others
    </h5>
    <div class="list-group list-group-flush">
        <a class="list-group-item list-group-item-action" href="<?php echo site_url('about') ?>">About Us</a>
        <a class="list-group-item list-group-item-action" href="<?php echo site_url('faq') ?>">FAQ</a>
        <a class="list-group-item list-group-item-action" href="<?php echo site_url('delivery_remark') ?>">Customer Remark</a>
        <a class="list-group-item list-group-item-action" href="<?php echo site_url('privacy') ?>">Privacy and Policy</a>
        <a class="list-group-item list-group-item-action" href="<?php echo site_url('t_and_c') ?>">Terms and Condition</a>
    </div>
</div>