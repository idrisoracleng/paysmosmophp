<?php $orders = $this->UserModel->getUserOrders()->collections; ?>

<div class="container">
  <br/>
  <?php $this->load->view('layouts/buyer/top_nav.php', array('title' => 'My Orders')); ?>
  <br/>
  <div class="row">
      <style>
        .nav-link.active {
          color: black !important;
          background: whitesmoke !important;
        }
      </style>
      <div class="col-sm-12">
        <div class="tab-content" id="v-pills-tabContent">
          <div class="tab-pane fade show active" id="v-pills-orders" role="tabpanel" aria-labelledby="v-pills-orders-tab">
              <!-- <h4 class="text-dark font-weight-bold">My Orders</h4> -->
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                  <a style="color: dodgerblue !important;" class="nav-link active text-primary" id="all-order-tab" data-toggle="tab" href="#all-order" role="tab" aria-controls="all-order" aria-selected="true">All Order</a>
                </li>
                <li class="nav-item">
                  <a style="color: dodgerblue !important;" class="nav-link text-primary" id="active-order-tab" data-toggle="tab" href="#active-order" role="tab" aria-controls="active-order" aria-selected="true">Active Order</a>
                </li>
                <li class="nav-item">
                  <a style="color: dodgerblue !important;" class="nav-link text-primary" id="pending-order-tab" data-toggle="tab" href="#pending-order" role="tab" aria-controls="pending-order" aria-selected="false">Pending Order</a>
                </li>
                <li class="nav-item">
                  <a style="color: dodgerblue !important;" class="nav-link text-primary" id="canceled-order-tab" data-toggle="tab" href="#canceled-order" role="tab" aria-controls="canceled-order" aria-selected="false">Canceled Order</a>
                </li>
              </ul>
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade" id="active-order" role="tabpanel" aria-labelledby="active-order-tab">
                  <?php if(count($orders) == 0){ ?>
                    <p class="alert alert-warning text-center">You Don't Have Any Order. Go to <a href="<?php echo site_url('/market'); ?>">Market</a> to Order Now</p>
                    <?php }else{ ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Order Id</th>
                                <th>Order Item</th>
                                <th>Order Bill</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $active = 0; foreach($orders as $order) { ?>
                            <?php if ($order->status == 'active') { $active++; ?>
                              <tr>
                                  <td><?php echo $order->order_id ?></td>
                                  <td>
                                    <?php foreach(unserialize($order->order_detail) as $det) { ?>
                                      <?php $productDetail = $this->db->get_where('products', ['product_id' => $det['options']['product_id']])->row(); ?>
                                      <img src="<?php echo site_url('public/images/products/'.$productDetail->code.'/01.jpg'); ?>" style="width: 100px; height: 100px;"/>
                                      <?php echo $det['name'].' N'.$det['price'].' | '.$det['qty'].br(); ?>
                                    <?php } ?>
                                  </td>
                                  <td><?php echo $this->cart->format_number($order->total_amount); ?></td>
																	<td><?php
																		switch($order->status) {
																			case 1:
																				echo "Pending ";
																				break;
																			case 2:
																				echo "Awaiting ".$this->db->get_where('cooperatives', ['cooperative_id' => $order->isCooperative])->row()->name." Cooperative Admin Approval";
																				break;
																			case 3:
																				echo "Awaiting Remita Approval. Ask buyer to take Remita from to the bank for approval";
																				break;
																			case 4:
																				echo "Awaiting Admin Final Approval";
																				break;
																			default:
																				echo "Order have been closed";
																		}
																	?></td>
                                  <td>
                                    <?php if ($order->status != 'canceled') { ?>
                                      <a class="btn btn-sm btn-danger" href="<?php echo site_url('buyer/orders/cancel/'.$order->id); ?>">Cancel</a>
                                    <?php } ?>
                                  </td>
                              </tr>
                            <?php } ?>
                          <?php } ?>
                        </tbody>
                    </table>
                    <?php if($active == 0){ ?>
                      <p class="alert alert-warning text-center">You Don't Have Any Active Order</p>
                    <?php }?>
                  <?php } ?>
                </div>
                <div class="tab-pane fade" id="pending-order" role="tabpanel" aria-labelledby="pending-order-tab">
                  <?php if(count($orders) == 0){ ?>
                    <p class="alert alert-warning text-center">You Don't Have Any Order. Go to <a href="<?php echo site_url('/market'); ?>">Market</a> to Order Now</p>
                    <?php }else{ ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>order id</th>
                                <th>order detail</th>
                                <th>order bill</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $pending = 0; foreach($orders as $order) { ?>
                            <?php if ($order->status == 1) { $pending++; ?>
                              <tr>
                                  <td><?php echo $order->order_id ?></td>
                                  <td>
                                    <?php foreach(unserialize($order->order_detail) as $det) { ?>
                                      <?php $productDetail = $this->db->get_where('products', ['product_id' => $det['options']['product_id']])->row(); ?>
                                      <img src="<?php echo site_url('public/images/products/'.$productDetail->code.'/01.jpg'); ?>" style="width: 100px; height: 100px;"/>
                                      <?php echo $det['name'].' N'.$det['price'].' | '.$det['qty'].br(); ?>
                                    <?php } ?>
                                  </td>
                                  <td><?php echo $this->cart->format_number($order->total_amount); ?></td>
                                  <td>
																			<?php
																		switch($order->status) {
																			case 1:
																				echo "Pending ";
																				break;
																			case 2:
																				echo "Awaiting ".$this->db->get_where('cooperatives', ['cooperative_id' => $order->isCooperative])->row()->name." Cooperative Admin Approval";
																				break;
																			case 3:
																				echo "Awaiting Remita Approval. Ask buyer to take Remita from to the bank for approval";
																				break;
																			case 4:
																				echo "Awaiting Admin Final Approval";
																				break;
																			default:
																				echo "Order have been closed";
																		}
																	?>
																	</td>
                                  <td>
                                    <?php if ($order->status != 'canceled') { ?>
                                      <a class="btn btn-sm btn-danger" href="<?php echo site_url('buyer/orders/cancel/'.$order->id); ?>">Cancel</a>
                                    <?php } ?><a class="btn btn-sm btn-danger" href="<?php echo site_url('buyer/orders/cancel/'.$order->id); ?>">Cancel</a>
                                  </td>
                              </tr>
                            <?php } ?>
                          <?php } ?>
                        </tbody>
                    </table>
                    <?php if($pending == 0){ ?>
                      <p class="alert alert-warning text-center">You Don't Have Any Pending Order</p>
                    <?php }?>
                  <?php } ?>
                </div>
                <div class="tab-pane fade" id="canceled-order" role="tabpanel" aria-labelledby="canceled-order-tab">
                  <?php if(count($orders) == 0){ ?>
                    <p class="alert alert-warning text-center">You Don't Have Any Order. Go to <a href="<?php echo site_url('/market'); ?>">Market</a> to Order Now</p>
                    <?php }else{ ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>order id</th>
                                <th>order detail</th>
                                <th>order bill</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $canceled = 0; foreach($orders as $order) { ?>
                            <?php if ($order->status == 'canceled') { $canceled++; ?>
                              <tr>
                                  <td><?php echo $order->order_id ?></td>
                                  <td>
                                      <?php foreach(unserialize($order->order_detail) as $det) { ?>
                                        <?php $productDetail = $this->db->get_where('products', ['product_id' => $det['options']['product_id']])->row(); ?>
                                        <img src="<?php echo site_url('public/images/products/'.$productDetail->code.'/01.jpg'); ?>" style="width: 100px; height: 100px;"/>
                                        <?php echo $det['name'].' N'.$det['price'].' | '.$det['qty'].br(); ?>
                                      <?php } ?>
                                  </td>
                                  <td><?php echo $this->cart->format_number($order->total_amount); ?></td>
                                  <td>
																				<?php
																		switch($order->status) {
																			case 1:
																				echo "Pending ";
																				break;
																			case 2:
																				echo "Awaiting ".$this->db->get_where('cooperatives', ['cooperative_id' => $order->isCooperative])->row()->name." Cooperative Admin Approval";
																				break;
																			case 3:
																				echo "Awaiting Remita Approval. Ask buyer to take Remita from to the bank for approval";
																				break;
																			case 4:
																				echo "Awaiting Admin Final Approval";
																				break;
																			case 5:
																				echo "Order Canceled";
																				break;
																			default:
																				echo "Order have been closed";
																		}
																	?>
																	</td>
                                  <td>
                                    <?php if ($order->status != 'canceled') { ?>
                                      <a class="btn btn-sm btn-danger" href="<?php echo site_url('buyer/orders/cancel/'.$order->id); ?>">Cancel</a>
                                    <?php } ?>
                                  </td>
                              </tr>
                            <?php } ?>
                          <?php } ?>
                        </tbody>
                    </table>
                    <?php if($canceled == 0){ ?>
                      <p class="alert alert-warning text-center">You Don't Have Any Canceled Order</p>
                    <?php }?>
                  <?php } ?>
                </div>
                <div class="tab-pane fade show active" id="all-order" role="tabpanel" aria-labelledby="all-order-tab">
                  <?php if(count($orders) == 0){ ?>
                      <p class="alert alert-warning text-center">You Don't Have Any Order. Go to <a href="<?php echo site_url('/market'); ?>">Market</a> to Order Now</p>
                    <?php }else{ ?>
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>order id</th>
                          <th>order detail</th>
                          <th>order bill</th>
                          <th>status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach($orders as $order){ ?>
                          <tr>
                              <td><?php echo $order->order_id ?></td>
                              <td>
                                  <?php foreach(unserialize($order->order_detail) as $det) { ?>
                                    <?php $productDetail = $this->db->get_where('products', ['product_id' => $det['options']['product_id']])->row(); ?>
                                    <img src="<?php echo site_url('public/images/products/'.$productDetail->code.'/01.jpg'); ?>" style="width: 100px; height: 100px;"/>
                                    <?php echo $det['name'].' N'.$det['price'].' | '.$det['qty'].br(); ?>
                                  <?php } ?>
                              </td>
                              <td><?php echo $this->cart->format_number($order->total_amount); ?></td>
                              <td>
																		<?php
																		switch($order->status) {
																			case 1:
																				echo "Pending ";
																				break;
																			case 2:
																				echo "Awaiting ".$this->db->get_where('cooperatives', ['cooperative_id' => $order->isCooperative])->row()->name." Cooperative Admin Approval";
																				break;
																			case 3:
																				echo "Awaiting Remita Approval. Ask buyer to take Remita from to the bank for approval";
																				break;
																			case 4:
																				echo "Awaiting Admin Final Approval";
																				break;
																			default:
																				echo "Order have been closed";
																		}
																	?>
															</td>
                              <td>
                                <?php if ($order->status != 'canceled') { ?>
                                  <a class="btn btn-sm btn-danger" href="<?php echo site_url('buyer/orders/cancel/'.$order->id); ?>">Cancel</a>
                                <?php } ?>
                              </td>
                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  <?php } ?>
                </div>
              </div>
          </div>
        </div>
      </div>

  </div>
</div>
