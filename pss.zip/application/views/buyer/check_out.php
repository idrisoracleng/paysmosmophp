<div class="container mt-5 mb-5">
    <?php $this->load->view('layouts/buyer/top_nav', array('title' => 'Checkout')); ?>
    <?php 
        $buyerData = $this->db->get_where('users', ['user_id' => $this->session->userdata('user')->user_id])->row();
        $buyerContact = $this->db->get_where('contacts', ['user_id' => $this->session->userdata('user')->user_id])->row();
    ?>
    <br/>
    <form method="POST" action="<?php echo site_url('buyer/checkout') ?>" msg="We are placing your order...">
    <div class="row">
        <div class="col-lg-9">

        <div id="faq" role="tablist" aria-multiselectable="true">

        <div class="card">

            <div class="card-header bg-white" role="tab" id="questionOne">
            <h5 class="card-title font-weight-bold">
                <a data-toggle="collapse" data-parent="#faq" href="#answerOne" aria-expanded="true" aria-controls="answerOne">
                Step 1. ADDRESS DETAILS
                </a>
            </h5>
            </div>

            <div id="answerOne" class="collapse show" role="tabcard" aria-labelledby="questionOne">
            <div class="card-body">
                <!-- form here -->
                <form action="<?php echo base_url();?>" method="post">

                <div class="row">
                    <div class="col-lg-12">
                    <div class="form-group">
                        <label for="">Full Name <span class="text-red">*</span></label>
                        <input type="text" name="full_name" value="<?php echo $buyerData->full_name; ?>" class="form-control input-sm">
                    </div>
                    </div>
<!-- 
                    <div class="col-lg-6">
                    <div class="form-group">
                        <label for="">Last Name <span class="text-red">*</span></label>
                        <input type="text" name="" value="" class="form-control input-sm">
                    </div>
                    </div> -->
                </div>


                <div class="row">
                    <div class="col-lg-3">
                    <div class="form-group">
                        <label for="">Mobile Phone No. <span class="text-red">*</span></label>
                        <input type="text" value="+234" class="form-control input-sm" readonly>
                    </div>
                    </div>

                    <div class="col-lg-9">
                    <div class="form-group">
                        <label for="">&nbsp</label>
                        <input type="text" name="phone_number" value="<?php echo ($buyerContact) ? $buyerContact->phone_number : ''; ?>" class="form-control input-sm">
                    </div>
                    </div>
                </div>



                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Address <span class="text-red">*</span></label>
                            <textarea name="name" rows="4" class="form-control" placeholder="Street Name / Building / Apartment No."><?php echo ($buyerContact) ? $buyerContact->billing_address : ''; ?></textarea>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="">Billing Address <span class="text-red">*</span></label>
                            <textarea name="billing_address" rows="4" class="form-control" placeholder="Street Name / Building / Apartment No."><?php echo ($buyerContact) ? $buyerContact->billing_address : ''; ?></textarea>
                        </div>
                    </div>

                </div>

                <!-- <div class="row">
                    <div class="col-lg-12">
                    <div class="form-group">
                        <label for="">State / Region <span class="text-red">*</span></label>
                        <select class="form-control" name="">
                        <option value="">Please select...</option>
                        </select>
                    </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-12">
                    <div class="form-group">
                        <label for="">City <span class="text-red">*</span></label>
                        <select class="form-control" name="">
                        <option value="">Please select...</option>
                        </select>
                    </div>
                    </div>

                </div> -->

                <div class="row">
                    <div class="col-lg-12">
                    <div class="form-group">
                        <label for=""> <span class="text-red">*</span> Required</label>

                    </div>
                    </div>

                </div>

                <!-- <button type="submit" name="submit" class="btn btn-warning btn-block"><b>SAVE AND CONTINUE</b></button> -->



                </form>
                <!-- form here -->
            </div>
            </div>

        </div>

 
        <!-- here -->
        <div class="bg-white">
            <div class="panel">
                <div class="panel-heading" style="padding:10px;">
                    <h5>
                        <a href="#" data-toggle="collapse" data-target="#improvementsPanel" aria-expanded="true" class=""><b >&nbsp&nbsp&nbsp&nbspStep 2. CONFIRM ORDER</b></a>
                    </h5>

                </div>
                <div id="improvementsPanel" class="panel-collapse collapse in" aria-expanded="true">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>PRODUCT</th>
                                <th>PRODUCT NAME</th>
                                <th>QUANTITY</th>
                                <th>UNIT PRICE</th>
                                <th>TOTAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($this->cart->contents() as $key => $item) { ?>
                                <?php
                                    $productData = $this->db->get_where('products', ['product_id' => $item['options']['product_id']])->row();
                                    // var_dump($productData); exit();
                                    // $sellerData = $this->db->get_where('sellers', ['seller_id' => $productData->owner_id])->row();
                                ?>
                                <tr>
                                    <td class="text-center">
                                        <img style="width: 100px; width: 100px;" src="<?php echo site_url('public/images/products/'.$productData->code.'/01.jpg');?>"/>
                                    </td>
                                    <td class="text-center">
                                        <b><?php echo $item['name'] ?></b>
                                    </td>
                                    <td class="text-center"><b><?php echo $item['qty'] ?></b></td>
                                    <td class="text-center"><b>₦<?php echo $this->cart->format_number($item['price']) ?></b></td>
                                    <td class="text-center"><b>₦<?php echo $this->cart->format_number($item['subtotal']); ?></b></td>
                                </tr>
                            <?php } ?>

                            <tr>
                                <td class="text-right font-weight-bold" colspan="4">Instalment Payment:</td>
                                <td class="text-center font-weight-bold"><b>₦<?php echo $this->cart->format_number($this->cart->total()/4); ?> / Month</b></td>
                            </tr>
							<tr>
                                <td class="text-right font-weight-bold" colspan="4">Sub-Total:</td>
                                <td class="text-center font-weight-bold"><b>₦<?php echo $this->cart->format_number($this->cart->total()); ?></b></td>
                            </tr>
                            <!-- <tr>
                                <td class="text-right font-weight-bold" colspan="4">Shipping Amount:</td>
                                <td class="text-center font-weight-bold"><b>₦3,600</b></td>
                                <input name="shipping_fee" type="hidden" value="3600"/>
                            </tr> -->

                        </tbody>
                        <tfoot>
                            <tr>
                                <th class="text-right" colspan="4" style="color:black;font-weight:bold;">Total</th>
                                <th class="text-center" style="color:black;font-weight:bold;"><b>₦<?php echo $this->cart->format_number($this->cart->total()) ?></b></th>
                            </tr>
                        </tfoot>
                    </table>
                    <span class="pull-right">
                        <button type="submit" class="btn btn-warning">Checkout</button>
                    </span>

                </div>
            </div>
        </div>
    </form>
        <!-- here -->





        </div>

        </div>
        <!-- end first column -->


        <div class="col-lg-3">
        <div class="card">
            <div class="card-header bg-white">
            <span class="text-dark font-weight-bold">YOUR ORDER(<?php echo count($this->cart->contents()); ?> item)</span>
            </div>
            <div class="card-body">
            <ul class="font-weight-bold">
                <?php foreach ($this->cart->contents() as $key => $item) { ?>
                    <?php
                        $productData = $this->db->get_where('products', ['product_id' => $item['options']['product_id']])->row();
                        // var_dump($productData); exit();
                        // $sellerData = $this->db->get_where('sellers', ['seller_id' => $productData->owner_id])->row();
                    ?>
                    <li>

                        <div class="row">
                            <div class="col-lg-6">
                            <img style="width: 100px; width: 100px;" src="<?php echo site_url('public/images/products/'.$productData->code.'/01.jpg');?>"/>
                            </div>
                            <div class="col-lg-6">
                            <span style="font-size:12px;"><?php echo $item['name']; ?></span><br>
                            <span style="color:gray;">Qty: <?php echo $item['qty']; ?></span><br>

                            </div>
                        </div>

                    </li>
                    <hr>
                    <li>Price  <span class="pull-right">₦<?php echo $this->cart->format_number($item['price']); ?></span></li><hr>
                    <li>Subtotal  <span class="pull-right">₦<?php echo $this->cart->format_number($item['subtotal']); ?></span></li><hr>
                <?php } ?>
                    <li>Total  <span class="pull-right text-warning"><?php echo $this->cart->format_number($this->cart->total()); ?></li>
                
            </ul>
            </div>
        </div>
        </div>





    </div>
</div>

<script>

</script>
