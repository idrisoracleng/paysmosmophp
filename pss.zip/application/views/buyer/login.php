<div class="container mb-5 mt-5">
  <div class="row d-flex justify-content-center">
    <div class="col-lg-6">
      <h4 class="text-center" style="color:red;"><b>Login</b></h4>
      <form class="" action="<?php echo site_url('/buyer/login') ?>" method="POST" msg="Logging In">
        <div class="form-group">
          <label for="">Email address</label>
          <input type="email" name="email" class="form-control" placeholder="Email address" required autofocus>
          <!-- <input type="hidden" name="acct_type" class="form-control" value="buyer" readonly> -->
        </div>

        <div class="form-group">
          <label for="">Password</label>
          <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>

        <div class="custom-control custom-checkbox mb-3">
          <!-- <input type="checkbox" class="custom-control-input" id="customCheck1"> -->
          <!-- <label class="custom-control-label" for="customCheck1">Remember password</label>
          <span class="pull-right"><a class="" href="#">Forgot password?</a></span> -->
        </div>
        <button class="btn btn-lg btn-warning btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Sign in</button>
        <hr>

        <p class="text-center text-dark"><b>Don't have an Account?</b></p>

        <div class="text-center">
          <a class="btn btn-primary btn-block" href="<?php echo site_url('buyer/register') ?>">CREATE AN ACCOUNT</a>

        </div>

      </form>
    </div>
  </div>
</div>
