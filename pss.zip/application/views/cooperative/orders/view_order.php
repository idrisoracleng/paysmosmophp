<?php  ?>

  <div id="wrapper">

<!-- Sidebar -->
<?php include APPPATH.'/views/layouts/admin/side_nav.php' ?>

<div id="content-wrapper">

  <div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="<?php echo site_url('/buyer/order/my_order') ?>">Orders</a>
      </li>
      <li class="breadcrumb-item active">Orders #<?php echo $order->order_id ?></li>
    </ol>

    <!-- DataTables Example -->
    <div class="card mb-3">
      <div class="card-header">
        	<button class="btn btn-primary btn-sm back-btn"><i class="fas fa-arrow-left"></i> back</button>
					<i class="fas fa-shopping-basket"></i>
          Order #<?php echo $order->order_id ?> Item
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-md-12">
              <table class="table table-bordered" id="dataTable1" width="100%">
                  <thead>
                      <tr>
                          <th>Product Name</th>
                          <th>Quantity</th>
                          <th>Price</th>
                          <!-- <th>Status</th> -->
                          <th>Subtotal</th>
                      </tr>
                  </thead>
                  <tbody>
										<?php
											foreach (unserialize($order->order_detail) as $key => $orderItem) {  ?>
												<tr>
													<td><?php echo $orderItem['name']; ?></td>
													<td><?php echo $orderItem['qty']; ?></td>
													<td><?php echo 'N '.$this->cart->format_number($orderItem['price']); ?></td>
													<td><?php echo 'N '.$this->cart->format_number($orderItem['price'] * $orderItem['qty']); ?></td>
												</tr>
											<?php } ?>
                  </tbody>
              </table>
							<?php if ($order->status == 2) { ?>
								<a 
									class="btn btn-sm btn-primary slink" 
									msg="Do you want to approve this order?"
									href="<?php echo site_url('cooperative/orders/approve/'.$order->order_id)?>"> Approve</a>
							<?php } ?>
							<?php 
								switch($order->status) {
									case 1:
										echo "Pending ";
										break;
									case 2:
										echo "Awaiting ".$this->db->get_where('cooperatives', ['cooperative_id' => $order->isCooperative])->row()->name." Cooperative Admin Approval";
										break;
									case 3:
										echo "Awaiting Remita Approval. Ask buyer to take Remita from to the bakn for approval";
										break;
									case 4:
										echo "Awaiting Admin Final Approval";
										break;
									default:
										echo "Order have been closed";
								}
							?>
          </div>
        </div>
      </div>
      
    </div>

  </div>

  <script>
    $(document).ready(function(){
    //   // alert("We are almost done here");
    //   var oldqty = $("#oldqty");
    //   var newqty = $("#newqty");

    //   var oldoto = $("#oldoto");
    //   var newoto = $("#newoto");

    //   oldqty.keyup(function(){
    //     newqty.val($(this).val());
    //   });

    //   oldoto.keyup(function(){
    //     newoto.val($(this).val());
    //   });
    });
  </script>
