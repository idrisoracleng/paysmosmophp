
<!--  Main Page Starts  -->
<div class="container" id="main">
    <!--  Upper Remark  -->
    <div class="row">
        <div class="col-md-2" id="left-side">
            <?php include 'layouts/general/side_bar_other.php' ?>
        </div>
        <div class="col-md-10" id="main-right">
            <div class="card products" style="border-radius: 10px; background: white; ">
                <h4 class="card-header products-header">
                    <span class="fa fa-shopping-cart"></span> Customer Remark 
                </h4>
                <div class="card-body" style="background: white; padding: 10px">
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias perspiciatis illum impedit nesciunt similique voluptatem tempora, cupiditate culpa dolores optio architecto maxime nihil debitis distinctio hic aspernatur aliquid possimus temporibus!
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illum quos nam fuga ipsam nisi nemo, natus praesentium quibusdam vel incidunt tempore eveniet sunt! Illum nam dolore nisi optio quam rerum.
                   Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat velit sed optio, mollitia, eius eveniet cupiditate facere at unde ipsa sunt natus praesentium consectetur? Quos maxime nulla iusto natus quidem.
                   Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus fuga nobis rerum accusantium quae quo, iste voluptatum animi tempore esse, odio corrupti. Eveniet nulla explicabo facilis doloremque officia ipsa sunt.
                   
                </div>
            </div>
            
        </div>
    </div>
</div>
