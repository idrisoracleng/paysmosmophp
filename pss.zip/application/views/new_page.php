<br>








<div class="container mb-5">
  <div class="row">
    <div class="col-lg-12">


        <div class="card">
          <div class="card-header h5 bg-white" style="color:black;">
          Recently viewed items
          </div>

          <div class="card-body">

          <div class="row flexiselDemo14">
            <div class="col"><img src="<?php echo base_url();?>resources/images/job1.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job2.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job3.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job4.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job5.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job6.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job7.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job8.jpg"/>
              <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job9.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job10.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>

            <div class="col"><img src="<?php echo base_url();?>resources/images/job11.jpg"/>
            <span style="color:black;">Lorem </span><br>
              <span style="color:black;">₦7,500</span><br>
              <span class="item-price"  style="color:gray;"><strike>₦20,000</strike></span>
            </div>



          </div>

        </div>
      </div>

    </div>
  </div>
</div>