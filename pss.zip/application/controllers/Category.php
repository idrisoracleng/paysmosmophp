<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {


    public function __construct(){
        parent::__construct();
    }


    public function index($cat_name = "all", $subcats = ''){
		$sublen = strlen($subcats);
		// $data = [];
		$data['cat'] = str_replace(['-', 'and', '_'], [' ', '&', "'"], $cat_name);
		$data['subcat'] = $subcats;
		$data['cats'] = null;
		$data['subcats'] = null;
		$data['cat_products'] = null;
		if($cat_name && $cat_name != 'all' && $sublen == 0){
			$cat = $this->db->get_where('category', ['name' => str_replace(['-', 'and', '_'], [' ', '&', "'"], $cat_name)])->row();
			if($cat){
				$data['subcats'] = $this->CategoryModel->getSubCategories($cat->id);
				$data['cat_products'] = $this->db->where('category_id', $cat->id)->get('products')->result();
				$data['page_title'] = $cat->name." Category";
			}
			// var_dump($data['cat_products']);
		}else{
			$data['cats'] = $this->db->get('category')->result();
			$data['page_title'] = "All Category";
		}
		$this->load->view('layouts/general/head.php', $data);
		// $this->load->view('layouts/general/nav.php', $data);
		$this->load->view('product/category', $data);
		$this->load->view('layouts/general/foot.php', $data);
    }
}
