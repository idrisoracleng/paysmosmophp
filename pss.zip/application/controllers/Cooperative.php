<?php

defined('BASEPATH') or die('Direct access not allowed');

class Cooperative extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->database();
	}

	public function login(){
		if ($this->input->post()) {
			// echo json_encode($this->input->post()); exit();
			$email = $this->input->post('email', TRUE);
			$pass = $this->input->post('password', TRUE);
			// $acct_type = $this->input->post('acct_type', TRUE);
			$logInInfo = $this->db->get_where('admins', ['email'=>$email, 'acct_type' => 'cooperative'])->row();
			if ($logInInfo && password_verify($pass, $logInInfo->password)) {
				$userData = $this->db->get_where('cooperatives', ['cooperative_id' => $logInInfo->user_id])->row();
				
				$this->session->set_userdata('user', $userData);
				$this->session->userdata('user')->loggedinas = $logInInfo->acct_type;
				$this->session->userdata('user')->acct_type = $logInInfo->acct_type;
				$url = ($this->session->tempdata('rfrom')) ? $this->session->tempdata('rfrom') : site_url('/'.$this->session->userdata('user')->loggedinas.'/index');
				if($this->session->tempdata('rfrom')){
					$this->session->unset_tempdata('rfrom');
				}
				echo json_encode(['status'=>1, 'msg' => 'Login Successful', 'redirect' => $url]);
				
			}else{
				echo json_encode(['status'=>0, 'msg' => 'Login Credentials is Invalid. Please Check your email and password', 'redirect' => 'noreload']);
			}
		} else {
			$data['scripts'] = ['main.js', 'forms.js'];
			$data['page_title'] = " | Cooperative | Login";
			$this->load->view('layouts/admin/head', $data);
			$this->load->view('layouts/admin/top_nav', $data);
			$this->load->view('cooperative/login', $data);
			$this->load->view('layouts/admin/foot', $data);
			// session_destroy();
		}
	}

	public function index () {
		if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/cooperative/login'));}
		if(!$this->isCooperativeAdmin()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		// var_dump($this->session->userdata('user'));
		$data['menus'] = $this->db->order_by('position', 'ASC')->get_where('menus', ['acct_type'=>'cooperative', 'active' => 1])->result();
		$data['page_title'] = " | Cooperative | Home";
		$data['scripts'] = ['main.js', 'forms.js'];
		$this->load->view('layouts/admin/head', $data);
		$this->load->view('layouts/admin/top_nav', $data);
		$this->load->view('cooperative/index', $data);
		$this->load->view('layouts/admin/foot', $data);
	}

	public function members($param1 = 'members_list', $param2 = null, $param3 = null) {
		if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/cooperative/login'));}
		if(!$this->isCooperativeAdmin()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$data['menus'] = $this->db->order_by('position', 'ASC')->get_where('menus', ['acct_type'=>'cooperative', 'active' => 1])->result();
		
		$data['scripts'] = ['main.js', 'forms.js'];
		if ($param1 == 'members_list' && $param2 == null) {
			$data['page_title'] = " | Cooperative | Members";
			$coopId = $this->session->userdata('user')->cooperative_id;
			$data['members'] = $this->db->order_by('created_at', 'DESC')->get_where('cooperative_member', ['cooperative_id' => $coopId])->result();
			$this->load->view('layouts/admin/head', $data);
			$this->load->view('layouts/admin/top_nav', $data);
			$this->load->view('cooperative/members/members_list', $data);
			$this->load->view('layouts/admin/foot', $data);
		} else if ($param1 == 'approve' && $param2 != null) {
			if ($this->db->where(['member_id' => $param2])->update('cooperative_member', ['approved' => 1]) && $this->db->where(['user_id' => $param2])->update('users', ['step' => 2])) {
				echo json_encode(['status' => 1, 'msg' => 'Member approved successfully', 'redirect' => 'reload']);
			} else {
				echo json_encode(['status' => 1, 'msg' => 'Unable to approve this user as a member of this cooperative! Please try again later ', 'redirect' => 'reload']);
			}
		} else if ($param1 == 'suspend' && $param2 != null) {
			if ($this->db->where(['member_id' => $param2])->update('cooperative_member', ['approved' => 0]) && $this->db->where(['user_id' => $param2])->update('users', ['step' => 4])) {
				echo json_encode(['status' => 1, 'msg' => 'Member suspended successfully', 'redirect' => 'reload']);
			} else {
				echo json_encode(['status' => 1, 'msg' => 'Unable to suspend this user as a member of this cooperative! Please try again later ', 'redirect' => 'reload']);
			}
		} else if ($param1 == 'activate' && $param2 != null) {
			if ($this->db->where(['member_id' => $param2])->update('cooperative_member', ['approved' => 1]) && $this->db->where(['user_id' => $param2])->update('users', ['step' => 0])) {
				echo json_encode(['status' => 1, 'msg' => 'Member activated successfully', 'redirect' => 'reload']);
			} else {
				echo json_encode(['status' => 1, 'msg' => 'Unable to activate this user as a member of this cooperative! Please try again later ', 'redirect' => 'reload']);
			}
		}
	}


	public function orders ($param1 = 'order_list', $param2 = null, $param3 = null) {
		if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/cooperative/login'));}
		if(!$this->isCooperativeAdmin()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$data['menus'] = $this->db->order_by('position', 'ASC')->get_where('menus', ['acct_type'=>'cooperative', 'active' => 1])->result();
		
		$data['scripts'] = ['main.js', 'forms.js'];

		if ($param1 == 'order_list' && $param2 == null) {
			$coopId = $this->session->userdata('user')->cooperative_id;
			$data['page_title'] = " | Cooperative | Orders";
			$data['orders'] = $this->db->get_where('orders', ['isCooperative' => $coopId])->result();
			$this->load->view('layouts/admin/head', $data);
			$this->load->view('layouts/admin/top_nav', $data);
			$this->load->view('cooperative/orders/order_list', $data);
			$this->load->view('layouts/admin/foot', $data);
		} else if ($param1 == 'view_order' && $param2 != null) {
			$data['order'] = $this->OrderModel->findOrFail($param2)->collection;
			$data['page_title'] = " | Cooperative | Orders | View Order";
			// $data['orders'] = $this->OrderModel->get()->collections;
			$this->load->view('layouts/admin/head', $data);
			$this->load->view('layouts/admin/top_nav', $data);
			$this->load->view('cooperative/orders/view_order', $data);
			$this->load->view('layouts/admin/foot', $data);
		} else if ($param1 == 'approve' && $param2 != null) {
			if ($this->db->where(['order_id' => $param2])->update('orders', ['status' => 0])) {
				echo json_encode(['status' => 1, 'msg' => 'Order approved successfully!', 'redirect' => 'reload']);
			} else {
				echo json_encode(['status' => 1, 'msg' => 'Unable to approve order! Please try again later', 'redirect' => 'reload']);
			}
		}
	}

	// Dont touch again
	public function isOnline(){
		if(!$this->session->userdata('user')) return false; else return true;;
	}

	public function logout(){
		$log['owner_id'] = $this->session->userdata('user')->user_id;
		$log['action'] = "You logged out of the system at ".date('Y-m-d H:i:s a');
		$this->ActivityModel->createLog($log);
		$this->session->unset_userdata('user');
		redirect(site_url('/admin/home'));
	}

	public function isCooperativeAdmin () {;
		if($this->session->userdata('user')->loggedinas == 'cooperative'){
			return true;
		}else{
			return false;
		}
	}

}