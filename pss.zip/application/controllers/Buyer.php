<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buyer extends CI_Controller {


    public function __construct(){
        parent::__construct();
    }

    public function index() {
        if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
		if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$this->revamp();
        $data['page_title'] = " Buyer Home";
		$this->load->view('layouts/general/head.php', $data);
		$this->load->view('buyer/index', $data);	
		$this->load->view('layouts/general/foot.php', $data);
    }

    public function home(){
        $this->index();
    }

    public function isOnline(){
        if(!$this->session->userdata('user')) return false; else return true;;
    }

    public function cart($param1 = 'my_cart'){

        if($param1 == 'my_cart'){
            $data['scripts'] = ['main.js', 'forms.js'];
			$data['page_title'] = " | Buyer | Cart | My Cart";
			$this->revamp();
            $data['profile'] = $this->session->userdata('user');
            // if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
            // if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
            
            $this->load->view('layouts/general/head.php', $data);
            $this->load->view('buyer/cart/my_cart', $data);	
            $this->load->view('layouts/general/foot.php', $data);
        }
        
    }

    public function addtocart(){
        
        $cart_item = $this->input->post();
        // echo json_encode($cart_item); exit();
        $data['id'] = 'cart'.random_string('numeric', 5);
        $data['name'] = $cart_item['name'];
        $data['options']['seller_id'] = $cart_item['owner_id'];
        $data['options']['product_id'] = $cart_item['product_id'];
        $data['options']['other_options'] = $cart_item['oto'];
        $data['options']['means'] = $cart_item['purchase_means'];
        $data['options']['sorted'] = false;
        $data['qty'] = $cart_item['qty'];
        $data['price'] = (int)str_replace(',', '', $cart_item['price']);
        // echo json_encode($data);
        $rowid = $this->cart->insert($data);
        // var_dump($rowid); exit();
        if($rowid){
            echo json_encode(['status'=>1, 'msg'=>$data['name']." is added to cart successfully", 'redirect'=>'reload', 'cart_len' => count($this->cart->contents())]);
        }else{
            echo json_encode(['status'=>0, 'msg'=>"An error was encountered please try again later"]);
        }
    }

    public function deletefromcart($rowid){
        // $rowid = $this->input->post();
        if($this->cart->remove($rowid)){
            echo json_encode(['status'=>1, 'msg'=>"Product have been removed from cart", 'redirect'=>'reload']);
        }else{
            echo json_encode(['status'=>0, 'msg'=>"An error occurred please try again later"]);
        }
    }

    public function updatecart(){
        $data = $this->input->post();
        $new_cartcontent['rowid'] = $data['rowid'];
        $new_cartcontent['options']['seller_id'] = $data['owner_id'];
        $new_cartcontent['options']['product_id'] = $data['product_id'];
        $new_cartcontent['options']['other_options'] = $data['oto'];
        $new_cartcontent['options']['sorted'] = false;
        $new_cartcontent['qty'] = $data['qty'];
        if($this->cart->update($new_cartcontent)){
            echo json_encode(['status'=>1, 'msg'=>'Cart Content Updated Successfully', 'redirect'=>'reload']);
        }else{
            echo json_encode(['status'=>0, 'msg'=>'An error occurred! Please try again later']);
        }
    }

    public function profile($param1 = 'view_profile', $param2 = 'users'){
        if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
        if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$this->revamp();
        $data['menus'] = $this->db->get_where('menus', ['acct_type'=>'buyer'])->result();
        if($param1 == 'view_profile'){
            $data['scripts'] = ['main.js', 'forms.js'];
            $data['page_title'] = " | Buyer | Profile | My Profile";
            $data['profile'] = $this->session->userdata('user');
            $this->load->view('layouts/general/head.php', $data);
            $this->load->view('buyer/profile/view_profile', $data);
            $this->load->view('layouts/general/foot.php', $data);
        }
        
        if($param1 == 'edit_profile'){
            $data['scripts'] = ['main.js', 'forms.js'];
            $data['page_title'] = " | Buyer | Profile | Edit Profile";
            $data['profile'] = $this->session->userdata('user');
            $this->load->view('layouts/general/head.php', $data);;
            $this->load->view('buyer/profile/edit_profile', $data);
            $this->load->view('layouts/general/foot.php', $data);
            // exit();
        }

        if($param1 == 'update'){
            $dddd = $this->input->post();
            
            $tocheck = ($param2 == 'users' || $param2 == 'contacts') ? 'user_id' : 'seller_id';
            if(!$this->db->get_where($param2, [$tocheck=>$this->session->userdata('user')->user_id])->row()){
                $this->db->insert($param2, [$tocheck=>$this->session->userdata('user')->user_id]);
            }
            // echo json_encode($tocheck); die();
            $update = $this->db->where($tocheck, $this->session->userdata('user')->user_id)->update($param2, $dddd);
            if($update){
                $loggedinas = $this->session->userdata('user')->loggedinas;
                $this->session->set_userdata('user', $this->db->get_where('users', ['user_id'=>$this->session->userdata('user')->user_id])->row());
                $this->session->userdata('user')->loggedinas = $loggedinas;
                echo json_encode(['status'=>1, 'msg'=>'Account Updated Successfully', 'redirect'=>'reload']);
            }else{
                echo json_encode(['status'=>0, 'msg'=>'An error occurred! Please try again later']);
            }
        }
    }

    public function checkout(){
        if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
		if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$this->revamp();
		$userData = $this->session->userdata('user');
		// echo json_encode($this->session->userdata('user')); exit();
        $order = new OrderModel();
        $order->order_detail = serialize($this->cart->contents());
        $order->total_amount = $this->cart->total();
        // $order->payment_type = $this->input->post('payment_type');
		$order->full_name = $this->input->post('full_name');
		$order->status = ($userData->cooperative_id != 'no_cooperative') ? 3 : 2;
        $order->isCooperative = ($userData->cooperative_id != 'no_cooperative') ? $userData->cooperative_id : 0;
        $order->billing_address = $this->input->post('billing_address');
        
        if($order->initialize()->save()){
            $this->cart->destroy();
            // redirect('buyer/orders/my_orders');
            echo json_encode(['status' => 1, 'msg' => 'Order placed successfully!', 'redirect' => site_url('buyer/orders/my_orders')]);
        } else {
            echo json_encode(['status' => 0, 'msg' => 'An error occurred! '.$this->db->error(), 'redirect' => 'noreload']);
        }
    }

    public function check_out() {
        if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
		if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$this->revamp();
        $data['page_title'] = " | Buyer | Checkout";
        $this->load->view('layouts/general/head.php', $data);
        $this->load->view('buyer/check_out', $data);	
        $this->load->view('layouts/general/foot.php', $data);
    }

    public function orders($param1 = 'my_orders', $param2 = null) {
        if(!$this->isOnline()){ $this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login')); }
        if(!$this->isBuyer()) redirect(site_url('/'.$this->session->userdata('user')->loggedinas.'/home'));
		$this->revamp();
        // $data['menus'] = $this->db->get_where('menus', ['acct_type'=>'buyer'])->result();

        if($param1 == 'my_orders'){
            $data['scripts'] = ['main.js', 'forms.js'];
            $data['page_title'] = " | Buyer | My Orders";
            $data['profile'] = $this->session->userdata('user');
            $this->load->view('layouts/general/head.php', $data);
            $this->load->view('buyer/orders/my_orders', $data);	
            $this->load->view('layouts/general/foot.php', $data);
        } else if ($param1 == 'cancel') {
            // $msg = $this->SomeDBFunctions->getOrderStatusMessage($this->input->post('status'));
            if ($this->db->where(['id' => $param2])->update('orders', ['status' => 5])) {
                redirect(site_url('buyer/home'));
            }
        }
        
    }

    public function login(){
		if ($this->input->post()) {
			$email = $this->input->post('email');
			$pass = $this->input->post('password');
			$userinfo = $this->db->get_where('users', ['email'=>$email])->row();
			if($userinfo && password_verify($pass, $userinfo->password)){
				$this->session->set_userdata('user', $userinfo);
				$this->session->userdata('user')->loggedinas = 'buyer';
				$url = ($this->session->tempdata('rfrom')) ? $this->session->tempdata('rfrom') : site_url('/'.$this->session->userdata('user')->loggedinas.'/home');
				if($this->session->tempdata('rfrom')){
					$this->session->unset_tempdata('rfrom');
				}
				echo json_encode(['status' => 1, 'msg' => 'Login Successful', 'redirect' => $url]);
				// redirect($url);
			}else{
				echo json_encode(['status' => 1, 'msg' => 'Login Credentials Not Correct', 'redirect' => 'noreload']);
				// redirect(site_url('buyer/login'));
			}
		} else {
			$data['scripts'] = ['main.js', 'forms.js'];
			$data['page_title'] = ' Buyer | Login';
			$this->load->view('layouts/general/head.php', $data);
			$this->load->view('buyer/login', $data);
			$this->load->view('layouts/general/foot.php', $data);
		}
    }

    public function log_in($token) {
        $userinfo = $this->db->get_where('users', ['token'=>$token])->row();
        if($userinfo){
            $this->session->set_userdata('user', $userinfo);
            $this->session->userdata('user')->loggedinas = 'buyer';
            $url = ($this->session->tempdata('rfrom')) ? $this->session->tempdata('rfrom') : site_url('/'.$this->session->userdata('user')->loggedinas.'/home');
            if($this->session->tempdata('rfrom')){
                $this->session->unset_tempdata('rfrom');
            }
            redirect($url);
        }else{
            redirect(site_url());
        }
    }

    public function register(){
        $data['scripts'] = ['main.js', 'forms.js'];
        $data['page_title'] = ' Buyer | Register';
        $this->load->view('layouts/general/head.php', $data);
        $this->load->view('buyer/register', $data);
        $this->load->view('layouts/general/foot.php', $data);
    }

    public function logout(){
        session_destroy();
        redirect(site_url());
    }

    public function isBuyer(){
        // if($this->session->)
        $acct_types = (array) explode(',', $this->session->userdata('user')->acct_type);
        if(in_array('buyer', $acct_types)){
            return true;
        }else{
            return false;
        }
	}
	
	public function revamp() {
		$userId = $this->session->userdata('user')->user_id;
		// var_dump($userId); die('Error');
		$userData = $this->db->get_where('users', ['user_id' => $userId])->row();
		$this->session->set_userdata('user', $userData);
	}
}
