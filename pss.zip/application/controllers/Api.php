<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class Api extends CI_Controller {

        public function __construct(){
            parent::__construct();
        }

        public function getSubCategories($id, $catid = null){
            $categories = $this->CategoryModel->getSubCategories($id);
            if($categories){
                $res = "<select class='category form-control custom-select-sm' name='categories[]' "."onchange='alert("."Hello world".")"."'>";
                $res .= "<option seleted value='NULL'> Select Sub Category</option>";
                foreach($categories as $category){
                    if($category['id'] == $catid) $selected = 'selected'; else $selected = '';
                    $newOPtion = "<option ".$selected." value='".$category['id']."'>".$category['name']."</option>";
                    $res .= $newOPtion;
				}
                $res .= "</select>"; 
            }else{
                $res = "<p class='alert alert-warning'>Last Category</p>";
            }
            
            echo $res;
            // echo json_encode($categories);
        }

        public function getCategoryImageUrl($id){
            $category = $this->CategoryModel->getCategory($id);
            echo "<small class='text-info'>Category Image Preview</small><br/><img style='height: 100px; width: 100px;' src=".site_url('/public/images/system/categories/'.strtolower(str_replace(' ', '-', $category['name'])).'.jpg')." >";
        }

        public function getSubCategoryImageUrl($id){
            $category = $this->SubCategoryModel->getSubCategory($id);
            echo "<small class='text-info'>Category Image Preview</small><br/><img style='height: 100px; width: 100px;' src=".site_url('/public/images/system/subcategories/'.strtolower(str_replace(' ', '-', $category['name'])).'.jpg')." >";
		}
		
		public function getSubCategory($id) {
			$subCats = $this->db->get_where('category', ['parent_id' => $id])->result();
			$data = "<label>Select Sub Category</label><select class='category form-control custom-select-sm'>";
			foreach ($subCats as $key => $cat) {
				$data .= "<option value='".$cat->id."'>".$cat->name."</option>";
			}
			$data .= "</select>";
			echo $data;
		}


		public function getLocals($id) {
			$subCats = $this->db->get_where('locals', ['state_id' => $id])->result();
			$data = "<select class='form-control custom-select-sm'><option selected disabled>Select Local Government</option>";
			foreach ($subCats as $key => $cat) {
				$data .= "<option value='".$cat->local_id."'>".$cat->local_name."</option>";
			}
			$data .= "</select>";
			echo $data;
		}

    }
?>
