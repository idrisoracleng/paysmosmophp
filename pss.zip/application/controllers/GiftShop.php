<?php

defined('BASEPATH') or exit('Direct Access not Allowed');

class GiftShop extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function isOnline(){
        if(!$this->session->userdata('user')) return false; else return true;;
    }

	public function index () {		
		if(!$this->isOnline()){$this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/buyer/login'));};
		$data['page_title'] = " Gift Shop ";
		$date_time = date('Y-m-d H:i:s');
		$sql = "SELECT gift.*, p.name, p.owner_id, p.code FROM gift_shop_items as gift JOIN products as p ON gift.product_id = p.product_id WHERE '$date_time' > gift.start_time AND '$date_time' < gift.end_time";
		$data['gift_items'] = $this->db->query($sql)->result_array();

		$this->load->view('layouts/general/head.php', $data);
		$this->load->view("product/gift_shop/gifts", $data);
		$this->load->view('layouts/general/foot.php', $data);
	}

	public function item ($id = null) {
		if(!$this->isOnline()){$this->session->set_tempdata('rfrom', current_url()); redirect(site_url('/seller/login'));};
		if ($id) {
			$data['page_title'] = " Gift Shop Item";
			$sql = "SELECT gift.*, p.owner_id, p.name, p.quantity, p.brand, p.code FROM gift_shop_items as gift JOIN products as p ON gift.product_id = p.product_id WHERE gift.id = '$id'";
			$data['item'] = $this->db->query($sql)->row();
			// var_dump($data['item']); exit();
			$this->load->view('layouts/general/head.php', $data);
			$this->load->view("product/gift_shop/this.php", $data);
			$this->load->view('layouts/general/foot.php', $data);
		} else {
			redirect(site_url('gift_shop'));
		}
	}
}
