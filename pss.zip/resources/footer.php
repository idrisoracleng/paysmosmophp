<!-- ============================================================================ -->
<!-- START :: FOOTER -->
<!-- ============================================================================ -->
<!-- <div class="jumbotron text-center" style="margin-top:30px; margin-bottom:0px; background-color:white; height:200px;">
  <p>Footer</p>
</div> -->
<!-- ============================================================================ -->
<!-- END :: FOOTER -->
<!-- ============================================================================ -->


<div class="w3l-middlefooter-sec">
			<div class="container py-md-5 py-sm-4 py-3">
				<div class="row footer-info w3-agileits-info">
					<!-- footer categories -->
					<div class="col-md-3 col-sm-6 footer-grids">
						<h3 class="text-white font-weight-bold mb-3">Categories</h3>
						<ul>
							<li class="mb-3">
								<a href="product.html">Mobiles </a>
							</li>
							<li class="mb-3">
								<a href="product.html">Computers</a>
							</li>
							<li class="mb-3">
								<a href="product.html">TV, Audio</a>
							</li>
							<li class="mb-3">
								<a href="product2.html">Smartphones</a>
							</li>
							<li class="mb-3">
								<a href="product.html">Washing Machines</a>
							</li>
							<li>
								<a href="product2.html">Refrigerators</a>
							</li>
						</ul>
					</div>
					<!-- //footer categories -->
					<!-- quick links -->
					<div class="col-md-3 col-sm-6 footer-grids mt-sm-0 mt-4">
						<h3 class="text-white font-weight-bold mb-3">Quick Links</h3>
						<ul>
							<li class="mb-3">
								<a href="about.html">About Us</a>
							</li>
							<li class="mb-3">
								<a href="contact.html">Contact Us</a>
							</li>
							<li class="mb-3">
								<a href="help.html">Help</a>
							</li>
							<li class="mb-3">
								<a href="faqs.html">Faqs</a>
							</li>
							<li class="mb-3">
								<a href="terms.html">Terms of use</a>
							</li>
							<li>
								<a href="privacy.html">Privacy Policy</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 footer-grids mt-md-0 mt-4">
						<h3 class="text-white font-weight-bold mb-3">Get in Touch</h3>
						<ul>
							<li class="mb-3">
								<i class="fas fa-map-marker"></i> 123 Sebastian, USA.</li>
							<li class="mb-3">
								<i class="fas fa-mobile"></i> 333 222 3333 </li>
							<li class="mb-3">
								<i class="fas fa-phone"></i> +222 11 4444 </li>
							<li class="mb-3">
								<i class="fas fa-envelope-open"></i>
								<a href="mailto:example@mail.com"> mail 1@example.com</a>
							</li>
							<li>
								<i class="fas fa-envelope-open"></i>
								<a href="mailto:example@mail.com"> mail 2@example.com</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 footer-grids w3l-agileits mt-md-0 mt-4">
						<!-- newsletter -->
						<h3 class="text-white font-weight-bold mb-3">Newsletter</h3>
						<p class="mb-3">Free Delivery on your first order!</p>
						<form action="#" method="post">
							<div class="form-group">
								<input type="email" class="form-control" placeholder="Email" name="email" required="">
								<input type="submit" value="Go">
							</div>
						</form>
						<!-- //newsletter -->
						<!-- social icons -->
						<div class="footer-grids  w3l-socialmk mt-3">
							<h3 class="text-white font-weight-bold mb-3">Follow Us on</h3>
							<div class="social">
								<ul>
									<li>
										<a class="icon fb" href="#">
											<i class="fab fa-facebook-f"></i>
										</a>
									</li>
									<li>
										<a class="icon tw" href="#">
											<i class="fab fa-twitter"></i>
										</a>
									</li>
									<li>
										<a class="icon gp" href="#">
											<i class="fab fa-google-plus-g"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<!-- //social icons -->
					</div>
				</div>
				<!-- //quick links -->
			</div>
		</div>

    <!-- ==========================================second segment ==================================-->
    <div class="agile-sometext py-md-5 py-sm-4 py-3">
			<div class="container">
				<!-- brands -->
				<div class="sub-some">
					<h5 class="font-weight-bold mb-2">Mobile &amp; Tablets :</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Android Phones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Smartphones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Feature Phones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Unboxed Phones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Refurbished Phones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2"> Tablets</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">CDMA Phones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Value Added Services</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Sell Old</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Used Mobiles</a>
						</li>
					</ul>
				</div>
				<div class="sub-some mt-4">
					<h5 class="font-weight-bold mb-2">Computers :</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Laptops </a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Printers</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Routers</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Ink &amp; Toner Cartridges</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Monitors</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Video Games</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Unboxed &amp; Refurbished Laptops</a>
						</li>
						<li>
							<a href="product.html" class="border-right pr-2">Assembled Desktops</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Data Cards</a>
						</li>
					</ul>
				</div>
				<div class="sub-some mt-4">
					<h5 class="font-weight-bold mb-2">TV, Audio &amp; Large Appliances :</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">TVs &amp; DTH</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Home Theatre Systems</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Hidden Cameras &amp; CCTVs</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Refrigerators</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Washing Machines</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2"> Air Conditioners</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Cameras</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Speakers</a>
						</li>
					</ul>
				</div>
				<div class="sub-some mt-4">
					<h5 class="font-weight-bold mb-2">Mobile &amp; Laptop Accessories :</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Headphones</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Power Banks </a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Backpacks</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Mobile Cases &amp; Covers</a>
						</li>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Pen Drives</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">External Hard Disks</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2"> Mouse</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Smart Watches &amp; Fitness Bands</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">MicroSD Cards</a>
						</li>
					</ul>
				</div>
				<div class="sub-some mt-4">
					<h5 class="font-weight-bold mb-2">Appliances :</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Trimmers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Hair Dryers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Emergency Lights</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Water Purifiers </a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Electric Kettles</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Hair Straighteners</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Induction Cooktops</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Sewing Machines</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2"> Geysers</a>
						</li>
					</ul>
				</div>
				<div class="sub-some mt-4">
					<h5 class="font-weight-bold mb-2">Popular on Electro Store</h5>
					<ul>
						<li class="m-sm-1">
							<a href="product.html" class="border-right pr-2">Offers &amp; Coupons</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Couple Watches</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Gas Stoves</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2"> Air Coolers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Air Purifiers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Headphones</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2"> Headsets</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Pressure Cookers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Sandwich Makers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Air Friers</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Irons</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">LED TV</a>
						</li>
						<li class="m-sm-1">
							<a href="product2.html" class="border-right pr-2">Sandwich Makers</a>
						</li>
					</ul>
				</div>
				<!-- //brands -->
				<!-- payment -->
				<div class="sub-some child-momu mt-4">
					<h5 class="font-weight-bold mb-3">Payment Method</h5>
					<ul>
						<li>
							<img src="images/pay2.png" alt="">
						</li>
						<li>
							<img src="images/pay5.png" alt="">
						</li>
						<li>
							<img src="images/pay1.png" alt="">
						</li>
						<li>
							<img src="images/pay4.png" alt="">
						</li>
						<li>
							<img src="images/pay6.png" alt="">
						</li>
						<li>
							<img src="images/pay3.png" alt="">
						</li>
						<li>
							<img src="images/pay7.png" alt="">
						</li>
						<li>
							<img src="images/pay8.png" alt="">
						</li>
						<li>
							<img src="images/pay9.png" alt="">
						</li>
					</ul>
				</div>
				<!-- //payment -->
			</div>
		</div>
    <!-- ==========================================second segment ==================================-->


    <!-- =====================================third segment=======================================-->
    <div class="copy-right py-3">
		<div class="container">
			<p class="text-center text-white">© 2018 Electro Store. All rights reserved | Design by
				<a href="http://w3layouts.com"> W3layouts.</a>
			</p>
		</div>
	</div>
    <!-- =====================================third segment=======================================-->













<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>

<script type="text/javascript" src="js/jquery.flexisel.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>


<script type="text/javascript">

$(window).load(function() {
    $("#flexiselDemo1").flexisel(
      {
          visibleItems: 1,
          itemsToScroll: 1,
          autoPlay: {
              enable: true,
              interval: 11000,
              pauseOnHover: true
          },
          responsiveBreakpoints: {
              portrait: {
                  changePoint:480,
                  visibleItems: 1,
                  itemsToScroll: 1
              },
              landscape: {
                  changePoint:640,
                  visibleItems: 1,
                  itemsToScroll: 1
              },
              tablet: {
                  changePoint:768,
                  visibleItems: 1,
                  itemsToScroll: 1
              }
          },
      }
    );

    $("#flexiselDemo2").flexisel({
        visibleItems: 4,
        itemsToScroll: 3,
        animationSpeed: 200,
        infinite: true,
        navigationTargetSelector: null,
        autoPlay: {
            enable: false,
            interval: 4000,
            pauseOnHover: true
        },
        responsiveBreakpoints: {
            portrait: {
                changePoint:480,
                visibleItems: 1,
                itemsToScroll: 1
            },
            landscape: {
                changePoint:640,
                visibleItems: 2,
                itemsToScroll: 2
            },
            tablet: {
                changePoint:768,
                visibleItems: 3,
                itemsToScroll: 3
            }
        },
        loaded: function(object) {
            console.log('Slider loaded...');
        },
        before: function(object){
            console.log('Before transition...');
        },
        after: function(object) {
            console.log('After transition...');
        },
        resize: function(object){
            console.log('After resize...');
        }
    });

    $("#flexiselDemo3").flexisel({
        visibleItems: 3,
        itemsToScroll: 1,
        autoPlay: {
            enable: true,
            interval: 6000,
            pauseOnHover: true
        }
    });

    $("#flexiselDemo4").flexisel({
        infinite: false
    });

    $("#flexiselDemo11").flexisel(
      {
          visibleItems: 5,
          itemsToScroll: 1,
          // autoPlay: {
          //     enable: true,
          //     interval: 5000,
          //     pauseOnHover: true
          // }
      }
    );

    $("#flexiselDemo12").flexisel(
      {
          visibleItems: 5,
          itemsToScroll: 1,
          autoPlay: {
              enable: true,
              interval: 8000,
              pauseOnHover: true
          }
      }
    );

    $("#flexiselDemo13").flexisel(
      {
          visibleItems: 5,
          itemsToScroll: 1,
          autoPlay: {
              enable: true,
              interval: 10000,
              pauseOnHover: true
          }
      }
    );

    $("#flexiselDemo14").flexisel(
      {
          visibleItems: 5,
          itemsToScroll: 1,
          autoPlay: {
              enable: true,
              interval: 9000,
              pauseOnHover: true
          }
      }
    );

    $("#flexiselDemo15").flexisel(
      {
          visibleItems: 5,
          itemsToScroll: 1,
          autoPlay: {
              enable: true,
              interval: 7000,
              pauseOnHover: true
          }
      }
    );

});


$(document).ready(function(){
  $(".dropdown").hover(
      function() {
          $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
          $(this).toggleClass('open');
      },
      function() {
          $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
          $(this).toggleClass('open');
      }
  );

// COUNTDOWN TIMER
  function timeConverter(UNIX_timestamp) {
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec;
    // return time;
    console.log(date);

    $("#timer #days").html("<span>Days</span>" + date);
    $("#timer #hours").html("<span>Hours</span>" + hour);
    $("#timer #minutes").html("<span>Minutes</span>" + min);
    $("#timer #seconds").html("<span>Seconds</span>" + sec);
  }

  function makeTimer() {

    var endTime = new Date("September 01, 2020 00:00:00");
    var endTime = (Date.parse(endTime)) / 1000; //replace these two lines with the unix timestamp from the server

    var now = new Date();
    var now = (Date.parse(now) / 1000);

    var timeLeft = endTime - now;

    var days = Math.floor(timeLeft / 86400);
    var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
    var Xmas95 = new Date('December 25, 1995 23:15:30');
    // console.log(Xmas95);
    // console.log(Date.parse(timeLeft * 1000));
    var hour = Xmas95.getHours();
    // console.log(hour);

    var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600)) / 60);
    var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

    if (hours < "10") {
      hours = "0" + hours;
    }
    if (minutes < "10") {
      minutes = "0" + minutes;
    }
    if (seconds < "10") {
      seconds = "0" + seconds;
    }

    $("#timer #days").html("<span>Days</span>" + days);
    $("#timer #hours").html("<span>Hours</span>" + hours);
    $("#timer #minutes").html("<span>Minutes</span>" + minutes);
    $("#timer #seconds").html("<span>Seconds</span>" + seconds);

  }

  setInterval(function() {
    makeTimer();
  }, 1000);

  // COUNTDOWN TIMER

});
</script>


</body>
</html>
